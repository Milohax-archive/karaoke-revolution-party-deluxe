-- Globals
RunOnce = 0
Pad = 0
-- update loop for swaptestworld
function ScriptUpdate ( )
	-- find out what the currently selected world is
	currentselected = SwapTestWorld.GetCurrentSelection()
	-- find out how many worlds there are
	numregistered = SwapTestWorld.GetNumRegistered()
	-- does the player want to go up the list
	if( LuaScriptPad.Up(Pad) > 0 ) then
		currentselected = math.mod( currentselected + numregistered-1, numregistered )
	end
	-- or down the list
	if( LuaScriptPad.Down(Pad) > 0 ) then
		currentselected = math.mod( currentselected + 1, numregistered )
	end
	-- set the currently selected world...might not have changed
	SwapTestWorld.SetCurrentSelection( currentselected )

	-- find out what the current difficulty level is
	difficulty = SwapTestWorld.GetDifficulty()
	-- does the player want to increment it...with wrapping
	if( LuaScriptPad.Circle(Pad) > 0 ) then
		difficulty = math.mod( difficulty + 1, 3 )
		-- set the difficulty level
		SwapTestWorld.SetDifficulty( difficulty )
	end

	-- get the number of languages and what the current is
	currentlanguage = SwapTestWorld.GetLanguage()
	-- does the player want to increment the current language
	if( LuaScriptPad.R1(Pad) > 0 ) then
		currentlanguage = math.mod( currentlanguage + 1, SwapTestWorld.GetNumLanguages() )
	end
	-- does the player want to decrement the current language
	if( LuaScriptPad.R2(Pad) > 0 ) then
		currentlanguage = math.mod( currentlanguage + SwapTestWorld.GetNumLanguages() - 1, SwapTestWorld.GetNumLanguages() )
	end

	-- if the language has changed then set the new one
	if( currentlanguage ~= SwapTestWorld.GetLanguage() ) then
		SwapTestWorld.SetLanguage( currentlanguage )
	end

	if( LuaScriptPad.Right(Pad) > 0 ) then
		val = math.mod( SwapTestWorld.GetMode() + 1 , 5 )
		SwapTestWorld.SetMode( val )
	end

	if( LuaScriptPad.Left(Pad) > 0 ) then
		val = math.mod( SwapTestWorld.GetMode() + 5 -1 , 5 )
		SwapTestWorld.SetMode( val )
	end

	if( LuaScriptPad.L1(Pad) > 0 ) then
		-- uses the built in math's lib...takes param 1 and divides by param 2 return the remainder
		val = math.mod( SwapTestWorld.GetMovie() + 1 , SwapTestWorld.GetNumMovies() )
		SwapTestWorld.SetMovie( val )
	end

	if( LuaScriptPad.L2(Pad) > 0 ) then
		-- uses the built in math's lib...takes param 1 and divides by param 2 return the remainder
		val = math.mod( SwapTestWorld.GetMovie() + SwapTestWorld.GetNumMovies() -1  , SwapTestWorld.GetNumMovies() )
		SwapTestWorld.SetMovie( val )
	end

	if( RunOnce == 0 ) then
		-- set the message to display scrolling at the bottom of the screen
		SwapTestWorld.SetScrollMessage( "Set from a Script, length tested in the setting function to avoid memory overwrites which would catch this if it was too long...\n" )
	end


	RunOnce = 1
end

-- just a message to show the script has been loaded...
Script.DisplayMessage("SwapTestWorld Script, This is a script generated debug message\n")
-- register the update function so it can be called from within the program
Script.AddFunctionToRegistry("ScriptUpdate", ScriptUpdate)

